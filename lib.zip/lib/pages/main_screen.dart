import 'package:flutter/material.dart';
import 'member/member_home_page.dart';
import 'member/member_portfolio_page.dart';
import 'member/member_trading_page.dart';
import 'member/member_profile_page.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const TradingPage(),
    const PortfolioPage(),
    const ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        // เก็บหน้าจอหลายหน้าซ้อนกัน แต่แสดงแค่หน้าเดียวตามที่เราเลือก
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed, // Needed for 4+ items
          currentIndex: _selectedIndex,
          selectedItemColor: const Color(0xFF800000), // Maroon for selected
          unselectedItemColor: Colors.grey,
          showUnselectedLabels: true,
          onTap: _onItemTapped,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'หน้าแรก'),
            BottomNavigationBarItem(
              icon: Icon(Icons.show_chart),
              label: 'ซื้อ-ขาย',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.pie_chart), // or savings icon
              label: 'ทองของฉัน',
            ),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'โปรไฟล์'),
          ],
        ),
      ),
    );
  }
}
